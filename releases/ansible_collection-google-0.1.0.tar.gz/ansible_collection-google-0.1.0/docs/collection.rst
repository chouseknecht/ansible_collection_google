Not really sure what we want to ultimately do here in this directory.

Definitely want docs for the whole collection to be located here. 

Do we want more directories for organisation?  A single rst file with sections? Open for discussion.

These docs will be displayed on the Collection page in Galaxy.